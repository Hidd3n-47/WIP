#include "pch.h"
#include "BulletManager.h"

void BulletManager::Update()
{
	for (int i = 0; i < bulletPool.size()-1;i++)
	{
		//bulletPool.at(i)->GetComponent<jci::Transform>()->AddToPosition(direction);
	}
}