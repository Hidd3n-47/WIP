#include "pch.h"
#include "EntityManager.h"

namespace jci {

EntityManager* EntityManager::m_instance = nullptr;



}