#pragma once

enum class ComponentTypes
{
	Transform = 0,
	SpriteRenderer,
	BoxCollider,
	NavBlock,
	AI,
	Impulse,
	Audio,
	Animation,
	Particle,
	Count // Total number of components.
};