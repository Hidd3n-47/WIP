#pragma once

#include "IComponent.h"

namespace jci {

class Particle : public IComponent
{
public:
	REGISTER_COMPONENT(ComponentTypes::Particle);

	void OnComponentAdd(Entity* entity) final { m_entity = entity; }
	void OnComponentRemove() final { }
private:
	Entity* m_entity	= nullptr;
	entId	m_id		= invalid_id;
};

} // Namespace jci.