#pragma once
#include "pch.h"

namespace jci {

class Random
{
public:
//	inline static void Init() { m_randomEngine.seed(std::random_device()()); }
//	/***
//	* Get a random number between 0.0f and 1.0f.
//	* 
//	*/
//	inline static float Rand() { return (float)m_distribution(m_randomEngine) / (float)std::numeric_limits<uint32>::max(); }
//private:
//	static std::mt19937 m_randomEngine;
//	static std::uniform_int_distribution<std::mt19937::result_type> m_distribution;
};

}